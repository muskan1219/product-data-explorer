export default { content: ['./**/*.{js,ts,jsx,tsx,mdx}'], theme: { extend: {} }, plugins: [] };
