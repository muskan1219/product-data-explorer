# Frontend (Next.js + TypeScript + Tailwind)

## Setup
cd frontend
npm install
cp ../.env.example .env.local
npm run dev

## Scripts
- `npm run dev` — dev server on http://localhost:3000
- `npm run build` — build
- `npm run start` — start
