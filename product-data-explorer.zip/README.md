# Product Data Explorer - Starter Implementation

This repository is a **starter scaffold** for the Product Data Explorer full-stack assignment.
It includes frontend (Next.js + TypeScript + Tailwind) and backend (NestJS) skeletons, Dockerfiles,
CI pipeline, and example scripts. It is intended to be complete enough to run locally, extend,
and deploy. **You must run additional setup steps** (install dependencies, add Playwright binaries, set env vars).

## What's included (high level)
- `frontend/` — Next.js (App Router) + TypeScript + Tailwind starter with pages:
  - Landing page (navigation headings)
  - Category page
  - Product grid
  - Product detail
  - About / README page
- `backend/` — NestJS TypeScript API with:
  - REST endpoints for navigation, categories, products
  - Placeholder scraping worker using Crawlee + Playwright (skeleton)
  - PostgreSQL database setup (schema + seed script)
- `infra/` — Dockerfiles and `docker-compose.yml` to run frontend, backend, and postgres locally.
- `ci/` — GitHub Actions workflow to lint, build and run tests.
- `.env.example` — Environment variables template

## How to use
1. Unzip and inspect files.
2. From project root: follow `frontend/README.md` and `backend/README.md` to install and run locally.
3. To push to GitHub:
   - `git init && git add . && git commit -m "initial scaffold"`
   - Create a new GitHub repo and `git remote add origin ...`
   - `git push -u origin main`
4. Deploy:
   - Frontend: Vercel / Netlify (set `NEXT_PUBLIC_API_URL`)
   - Backend: Render / Railway / Fly.io (set DB and secrets)
   - Or use `docker-compose` to run locally.

## Limitations
- This scaffold contains working endpoints and UI wiring, but the scraping implementation is a **skeleton** and must be completed with proper Crawlee/Playwright installation and ethical scraping controls.
- You will need to install dependencies and run build scripts.
