# Backend (NestJS) - Starter

## Setup
cd backend
npm install
cp ../.env.example .env
npm run start:dev

## Scripts
- `npm run start:dev` — run dev server (ts-node)
- `npm run build` — build
- `npm run start:prod` — run compiled app
